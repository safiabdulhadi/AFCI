<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base de php</title>
</head>
<body>
    <ol>
        <li>
            <h3>Syntaxe :</h3>
            <ol>
                <li><a href="./01-syntaxe/01-variable.php">Variables</a></li>
                <li><a href="./01-syntaxe/02-condition.php">Conditions</a></li>
                <li><a href="./01-syntaxe/03-boucle.php">Boucles</a></li>
                <li><a href="./01-syntaxe/04-fonction.php">Fonctions</a></li>
                <li><a href="./01-syntaxe/05-include.php">Include</a></li>
                <li><a href="./01-syntaxe/06-goto.php">Go to</a></li>
                <li><a href="./01-syntaxe/07-a-session.php">Session</a></li>
                <li><a href="./01-syntaxe/08-date.php">Dates</a></li>
                <li><a href="./01-syntaxe/09-a-header.php">Header</a></li>
            </ol>
        </li>
        <li>
            <h3>Formulaire :</h3>
            <ol>
                <li><a href="./02-form/01-get.php">En GET</a></li>
                <li><a href="./02-form/02-post.php">En POST</a></li>
                <li><a href="./02-form/03-file.php">Téléversement</a></li>
                <li><a href="./02-form/04-connexion.php">Connexion</a></li>
                <li><a href="./02-form/05-deconnexion.php">Déconnexion</a></li>
            </ol>
        </li>
    </ol>
</body>
</html>