
</main>
<footer>
    <a href="/">Retourner à l'accueil</a>
</footer>
</body>
</html>