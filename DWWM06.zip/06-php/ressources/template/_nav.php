<nav>
    <ul>
        <li><a href="#para1">paragraphe 1</a></li>
        <li><a href="#para2">paragraphe 2</a></li>
        <li><a href="#para3">paragraphe 3</a></li>
        <li><a href="#para4">paragraphe 4</a></li>
        <li><a href="#para5">paragraphe 5</a></li>
    </ul>
</nav>